
//g++ main.cpp exptree.cpp -o arbol_expresiones.exe -L. -lraylib -lopengl32 -lgdi32 -lwinmm
//g++ main.cpp exptree.cpp -o arbol_avanzado.exe -L. -lraylib -lopengl32 -lgdi32 -lwinmm
//.\arbol_expresiones

#include "raylib.h"
#include "exptree.h" 
#include <stdlib.h> 

int main() {
    InitWindow(100, 100, "Inicializando..."); 
    int screenWidth = GetMonitorWidth(0);   
    int screenHeight = GetMonitorHeight(0);
    CloseWindow(); 

    int windowWidth = screenWidth - 100;
    int windowHeight = screenHeight - 150;
    InitWindow(windowWidth, windowHeight, "Analizador Matematico (Infija a Polaca)");
    SetTargetFPS(60);

    ExpTree *tree = new ExpTree(); 
    bool treeBuilt = false;

    char *inputText = (char*)malloc(256 * sizeof(char));
    *inputText = '\0';
    char *cursor = inputText; 

    char *postfijaGenerada = nullptr;
    char *polaca = nullptr;      // Preorden
    char *infija = nullptr;      // Inorden
    char *polacaInv = nullptr;   // Postorden

    int startX = windowWidth / 2;
    int startY = 240;

    while (!WindowShouldClose()) {
        if (!treeBuilt) {
            int key = GetCharPressed();
            while (key > 0) {
                if ((key >= 32) && (key <= 125) && (cursor - inputText < 255)) {
                    *cursor = (char)key;
                    cursor++; *cursor = '\0'; 
                }
                key = GetCharPressed();
            }

            if (IsKeyPressed(KEY_BACKSPACE) && cursor > inputText) {
                cursor--; *cursor = '\0';
            }

            if (IsKeyPressed(KEY_ENTER) && cursor > inputText) {
                // Transformamos tu texto normal a Polaca Inversa internamente
                postfijaGenerada = tree->infixToPostfix(inputText);
                
                // Construimos el árbol
                tree->buildTree(postfijaGenerada);
                
                // Obtenemos los recorridos
                polaca = tree->getPreOrden();
                infija = tree->getInOrden();
                polacaInv = tree->getPostOrden();
                treeBuilt = true;
            }
        } else {
            if (IsKeyPressed(KEY_BACKSPACE)) {
                delete tree; tree = new ExpTree(); 
                free(postfijaGenerada); free(polaca); free(infija); free(polacaInv);
                cursor = inputText; *cursor = '\0';
                treeBuilt = false;
            }
        }

        BeginDrawing();
        ClearBackground(LIGHTGRAY); 

        if (!treeBuilt) {
            DrawText("ESCRIBE TU EXPRESION MATEMATICA NORMAL", 50, 50, 22, DARKGRAY);
            DrawText("El algoritmo Shunting-Yard armara el arbol automaticamente.", 50, 90, 18, DARKGRAY);
            DrawText("Ejemplo: sen(40) + cos(50) + 9", 50, 130, 20, DARKBLUE);
            DrawText("Ejemplo: ( 5 + 3 ) * raiz( 144 )", 50, 160, 20, DARKBLUE);
            
            DrawText("Escribe aqui y presiona ENTER:", 50, 220, 20, MAROON);
            DrawText(inputText, 50, 260, 24, BLACK);
            
            if (((int)(GetTime() * 2)) % 2 == 0) {
                int textWidth = MeasureText(inputText, 24);
                DrawText("_", 52 + textWidth, 260, 24, MAROON);
            }
        } else {
            DrawText("ARBOL GENERADO AUTOMATICAMENTE", 20, 20, 22, DARKGRAY);
            
            DrawText("Entrada del Usuario:", 20, 50, 18, BLACK);
            DrawText(inputText, 250, 50, 18, BLACK);

            DrawText("Preorden (Prefijo):", 20, 80, 18, MAROON);
            DrawText(polaca, 250, 80, 18, MAROON);
            
            DrawText("Inorden (Infijo):", 20, 110, 18, DARKBLUE);
            DrawText(infija, 250, 110, 18, DARKBLUE);
            
            DrawText("Polaca Inversa (Postfijo):", 20, 140, 18, DARKGREEN);
            DrawText(polacaInv, 250, 140, 18, DARKGREEN);
            
            DrawText("[ Presiona BACKSPACE para reiniciar ]", 20, windowHeight - 40, 18, RED);
            
            tree->draw(startX, startY);
        }

        EndDrawing();
    }

    free(inputText);
    if (treeBuilt) { free(postfijaGenerada); free(polaca); free(infija); free(polacaInv); }
    delete tree;
    CloseWindow();
    return 0;
}