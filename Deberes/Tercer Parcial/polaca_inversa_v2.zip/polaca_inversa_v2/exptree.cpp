#include "exptree.h"
#include "raylib.h"
#include <stdlib.h> 

// =========================================================
// HERRAMIENTAS INDEPENDIENTES PARA PUNTEROS
// =========================================================
bool sonIguales(const char *s1, const char *s2) {
    while (*s1 != '\0' && *s2 != '\0') {
        if (*s1 != *s2) return false;
        s1++; s2++;
    }
    return (*s1 == '\0' && *s2 == '\0');
}

int getPrecedencia(const char *op) {
    if (sonIguales(op, "+") || sonIguales(op, "-")) return 1;
    if (sonIguales(op, "*") || sonIguales(op, "/")) return 2;
    if (sonIguales(op, "^")) return 3;
    if (sonIguales(op, "sen") || sonIguales(op, "cos") || sonIguales(op, "raiz")) return 4;
    return 0;
}

// =========================================================
// PILA DE TEXTOS PURA (Para el algoritmo Shunting-Yard)
// =========================================================
class StringNode {
public:
    char *str;
    StringNode *next;
    StringNode(const char *val) {
        int len = 0; const char *p = val; while(*p != '\0'){ len++; p++; }
        str = (char*)malloc(sizeof(char)*(len+1));
        char *d = str; const char *s = val; while(*s != '\0'){ *d = *s; d++; s++; }
        *d = '\0';
        next = nullptr;
    }
    ~StringNode() { free(str); }
};

class StringStack {
public:
    StringNode *topNode;
    StringStack() { topNode = nullptr; }
    void push(const char *val) {
        StringNode *n = new StringNode(val);
        n->next = topNode;
        topNode = n;
    }
    char* pop() {
        if (topNode == nullptr) return nullptr;
        int len = 0; char *p = topNode->str; while(*p != '\0'){ len++; p++; }
        char *copy = (char*)malloc(sizeof(char)*(len+1));
        char *d = copy; char *s = topNode->str; while(*s != '\0'){ *d = *s; d++; s++; }
        *d = '\0';
        StringNode *temp = topNode;
        topNode = topNode->next;
        delete temp;
        return copy;
    }
    char* top() { return (topNode == nullptr) ? nullptr : topNode->str; }
    bool isEmpty() { return topNode == nullptr; }
};

// =========================================================
// MÉTODOS DE EXPTREE
// =========================================================
bool ExpTree::isEqual(const char *s1, const char *s2) { return sonIguales(s1, s2); }

void ExpTree::appendStr(char *dest, const char *src) {
    char *d = dest;
    while (*d != '\0') d++; 
    const char *s = src;
    while (*s != '\0') { *d = *s; d++; s++; }
    *d = ' '; 
    d++;
    *d = '\0';
}

char* ExpTree::copyStr(const char *start, int len) {
    char *str = (char*)malloc(sizeof(char) * (len + 1));
    char *t = str; const char *s = start;
    while (s != start + len) { *t = *s; t++; s++; }
    *t = '\0';
    return str;
}

bool ExpTree::isBinary(const char *t) {
    return isEqual(t, "+") || isEqual(t, "-") || isEqual(t, "*") || isEqual(t, "/") || isEqual(t, "^");
}

bool ExpTree::isUnary(const char *t) {
    return isEqual(t, "sen") || isEqual(t, "cos") || isEqual(t, "raiz");
}

// --- Algoritmo de Traducción de Infija a Postfija ---
char* ExpTree::infixToPostfix(const char *infix) {
    char *postfix = (char*)malloc(sizeof(char)*1024);
    *postfix = '\0';
    StringStack stack;

    const char *p = infix;
    while (*p != '\0') {
        while (*p == ' ') p++; // Saltar espacios
        if (*p == '\0') break;

        const char *start = p;
        // El motor ahora sabe separar automáticamente los paréntesis
        if (*p == '(' || *p == ')') {
            p++;
        } else {
            while (*p != ' ' && *p != '\0' && *p != '(' && *p != ')') p++;
        }

        int len = p - start;
        char *token = copyStr(start, len);

        if (sonIguales(token, "(")) {
            stack.push(token);
        } else if (sonIguales(token, ")")) {
            while (!stack.isEmpty() && !sonIguales(stack.top(), "(")) {
                char *op = stack.pop();
                appendStr(postfix, op);
                free(op);
            }
            if (!stack.isEmpty()) { char *openP = stack.pop(); free(openP); }
        } else if (isBinary(token) || isUnary(token)) {
            int prec = getPrecedencia(token);
            while (!stack.isEmpty() && !sonIguales(stack.top(), "(") && getPrecedencia(stack.top()) >= prec) {
                char *op = stack.pop();
                appendStr(postfix, op);
                free(op);
            }
            stack.push(token);
        } else {
            // Es un número
            appendStr(postfix, token);
        }
        free(token);
    }

    while (!stack.isEmpty()) {
        char *op = stack.pop();
        appendStr(postfix, op);
        free(op);
    }

    return postfix;
}

// --- Implementación Nodo ---
ExpNode::ExpNode(const char *val) {
    int len = 0; const char *p = val; while (*p != '\0') { len++; p++; }
    data = (char*)malloc(sizeof(char) * (len + 1));
    char *d = data; const char *s = val; while (*s != '\0') { *d = *s; d++; s++; }
    *d = '\0';
    left = nullptr; right = nullptr;
}

void ExpNode::draw(int x, int y, int offsetX) {
    if (left != nullptr) {
        int childX = x - offsetX; int childY = y + 70;
        DrawLine(x, y, childX, childY, DARKGRAY);
        left->draw(childX, childY, offsetX / 2);
    }
    if (right != nullptr) {
        int childX = x + offsetX; int childY = y + 70;
        DrawLine(x, y, childX, childY, DARKGRAY);
        right->draw(childX, childY, offsetX / 2);
    }

    bool isOpBin = sonIguales(data, "+") || sonIguales(data, "-") || sonIguales(data, "*") || sonIguales(data, "/") || sonIguales(data, "^");
    bool isOpUn = sonIguales(data, "sen") || sonIguales(data, "cos") || sonIguales(data, "raiz");
    
    Color nodeColor = (isOpBin || isOpUn) ? PURPLE : DARKGREEN;
    if (isOpUn) nodeColor = ORANGE;

    DrawCircle(x, y, 22, nodeColor);
    DrawCircleLines(x, y, 22, RAYWHITE); 
    int textWidth = MeasureText(data, 14);
    DrawText(data, x - (textWidth / 2), y - 7, 14, RAYWHITE);
}

// --- Implementación Pila del Arbol ---
StackNode::StackNode(ExpNode *node) { treeNode = node; next = nullptr; }
void ExpTree::push(ExpNode *node) { StackNode *newNode = new StackNode(node); newNode->next = top; top = newNode; }
ExpNode* ExpTree::pop() {
    if (top == nullptr) return nullptr;
    ExpNode *res = top->treeNode; StackNode *temp = top; top = top->next;
    free(temp); return res;
}

// --- Implementación Árbol ---
ExpTree::ExpTree() { root = nullptr; top = nullptr; }
void ExpTree::buildTree(const char *postfix) {
    const char *p = postfix; 
    while (*p != '\0') { 
        while (*p == ' ') p++; 
        if (*p == '\0') break;

        const char *start = p;
        while (*p != ' ' && *p != '\0') p++;
        
        int len = p - start;
        char *token = copyStr(start, len);

        if (isBinary(token)) {
            ExpNode *node = new ExpNode(token);
            node->right = pop(); node->left = pop();
            push(node);
        } else if (isUnary(token)) {
            ExpNode *node = new ExpNode(token);
            node->right = nullptr; node->left = pop();    
            push(node);
        } else {
            push(new ExpNode(token));
        }
        free(token);
    }
    root = pop(); 
}

void ExpTree::preOrden(ExpNode *node, char *res) {
    if (node == nullptr) return;
    appendStr(res, node->data); preOrden(node->left, res); preOrden(node->right, res);
}
void ExpTree::inOrden(ExpNode *node, char *res) {
    if (node == nullptr) return;
    if (node->left != nullptr) appendStr(res, "("); 
    inOrden(node->left, res);
    appendStr(res, node->data);
    inOrden(node->right, res);
    if (node->right != nullptr) appendStr(res, ")");
}
void ExpTree::postOrden(ExpNode *node, char *res) {
    if (node == nullptr) return;
    postOrden(node->left, res); postOrden(node->right, res); appendStr(res, node->data);
}

char* ExpTree::getPreOrden() { char *buffer = (char*)malloc(1024); *buffer = '\0'; preOrden(root, buffer); return buffer; }
char* ExpTree::getInOrden() { char *buffer = (char*)malloc(1024); *buffer = '\0'; inOrden(root, buffer); return buffer; }
char* ExpTree::getPostOrden() { char *buffer = (char*)malloc(1024); *buffer = '\0'; postOrden(root, buffer); return buffer; }
void ExpTree::draw(int startX, int startY) { if (root != nullptr) root->draw(startX, startY, startX / 2); }