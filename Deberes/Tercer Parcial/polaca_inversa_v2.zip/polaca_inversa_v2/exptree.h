#ifndef EXPTREE_H
#define EXPTREE_H

class ExpNode {
public:
    char *data; 
    ExpNode *left;
    ExpNode *right;

    ExpNode(const char *val);
    void draw(int x, int y, int offsetX); 
};

class StackNode {
public:
    ExpNode *treeNode;
    StackNode *next;
    StackNode(ExpNode *node);
};

class ExpTree {
private:
    ExpNode *root;
    StackNode *top; 

    void push(ExpNode *node);
    ExpNode* pop();

    void preOrden(ExpNode *node, char *res);
    void inOrden(ExpNode *node, char *res);
    void postOrden(ExpNode *node, char *res);

    void appendStr(char *dest, const char *src);
    bool isEqual(const char *s1, const char *s2);
    bool isBinary(const char *token);
    bool isUnary(const char *token);
    char* copyStr(const char *start, int len);

public:
    ExpTree();
    // --- NUEVA FUNCIÓN ---
    char* infixToPostfix(const char *infix); 

    void buildTree(const char *postfix); 
    
    char* getPreOrden();
    char* getInOrden();
    char* getPostOrden();
    
    void draw(int startX, int startY);
};

#endif