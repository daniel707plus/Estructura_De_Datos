#include "bplus.h"
#include "raylib.h"
#include <string>

// Máximo de llaves (Orden 4)
const int MAX = 3;

BPlusNode::BPlusNode() {
    key = new int[MAX];
    ptr = new BPlusNode *[MAX + 1];
    next = nullptr;
}

BPlusTree::BPlusTree() {
    root = nullptr;
}

void BPlusTree::insert(int x) {
    if (root == nullptr) {
        root = new BPlusNode;
        root->key[0] = x;
        root->IS_LEAF = true;
        root->size = 1;
    } else {
        BPlusNode *cursor = root;
        BPlusNode *parent;
        // Bajar hasta la hoja correspondiente
        while (cursor->IS_LEAF == false) {
            parent = cursor;
            for (int i = 0; i < cursor->size; i++) {
                if (x < cursor->key[i]) {
                    cursor = cursor->ptr[i];
                    break;
                }
                if (i == cursor->size - 1) {
                    cursor = cursor->ptr[i + 1];
                    break;
                }
            }
        }
        
        // Si hay espacio en la hoja
        if (cursor->size < MAX) {
            int i = 0;
            while (x > cursor->key[i] && i < cursor->size) i++;
            for (int j = cursor->size; j > i; j--) {
                cursor->key[j] = cursor->key[j - 1];
            }
            cursor->key[i] = x;
            cursor->size++;
            cursor->ptr[cursor->size] = cursor->ptr[cursor->size - 1];
            cursor->ptr[cursor->size - 1] = nullptr;
        } else {
            // Dividir la hoja
            BPlusNode *newLeaf = new BPlusNode;
            int virtualNode[MAX + 1];
            for (int i = 0; i < MAX; i++) virtualNode[i] = cursor->key[i];
            
            int i = 0, j;
            while (x > virtualNode[i] && i < MAX) i++;
            for (int j = MAX; j > i; j--) virtualNode[j] = virtualNode[j - 1];
            virtualNode[i] = x;
            
            newLeaf->IS_LEAF = true;
            cursor->size = (MAX + 1) / 2;
            newLeaf->size = MAX + 1 - (MAX + 1) / 2;
            
            // Conectar la lista enlazada (El puntero next)
            newLeaf->next = cursor->next;
            cursor->next = newLeaf;
            
            for (i = 0; i < cursor->size; i++) cursor->key[i] = virtualNode[i];
            for (i = 0, j = cursor->size; i < newLeaf->size; i++, j++) newLeaf->key[i] = virtualNode[j];
            
            if (cursor == root) {
                BPlusNode *newRoot = new BPlusNode;
                newRoot->key[0] = newLeaf->key[0];
                newRoot->ptr[0] = cursor;
                newRoot->ptr[1] = newLeaf;
                newRoot->IS_LEAF = false;
                newRoot->size = 1;
                root = newRoot;
            } else {
                insertInternal(newLeaf->key[0], parent, newLeaf);
            }
        }
    }
}

void BPlusTree::insertInternal(int x, BPlusNode *cursor, BPlusNode *child) {
    if (cursor->size < MAX) {
        int i = 0;
        while (x > cursor->key[i] && i < cursor->size) i++;
        for (int j = cursor->size; j > i; j--) cursor->key[j] = cursor->key[j - 1];
        for (int j = cursor->size + 1; j > i + 1; j--) cursor->ptr[j] = cursor->ptr[j - 1];
        cursor->key[i] = x;
        cursor->size++;
        cursor->ptr[i + 1] = child;
    } else {
        // Dividir nodo interno
        BPlusNode *newInternal = new BPlusNode;
        int virtualKey[MAX + 1];
        BPlusNode *virtualPtr[MAX + 2];
        for (int i = 0; i < MAX; i++) virtualKey[i] = cursor->key[i];
        for (int i = 0; i < MAX + 1; i++) virtualPtr[i] = cursor->ptr[i];
        
        int i = 0, j;
        while (x > virtualKey[i] && i < MAX) i++;
        for (int j = MAX; j > i; j--) virtualKey[j] = virtualKey[j - 1];
        virtualKey[i] = x;
        for (int j = MAX + 1; j > i + 1; j--) virtualPtr[j] = virtualPtr[j - 1];
        virtualPtr[i + 1] = child;
        
        newInternal->IS_LEAF = false;
        cursor->size = (MAX + 1) / 2;
        newInternal->size = MAX - (MAX + 1) / 2;
        
        for (i = 0, j = cursor->size + 1; i < newInternal->size; i++, j++) newInternal->key[i] = virtualKey[j];
        for (i = 0, j = cursor->size + 1; i < newInternal->size + 1; i++, j++) newInternal->ptr[i] = virtualPtr[j];
        
        if (cursor == root) {
            BPlusNode *newRoot = new BPlusNode;
            newRoot->key[0] = cursor->key[cursor->size];
            newRoot->ptr[0] = cursor;
            newRoot->ptr[1] = newInternal;
            newRoot->IS_LEAF = false;
            newRoot->size = 1;
            root = newRoot;
        } else {
            insertInternal(cursor->key[cursor->size], findParent(root, cursor), newInternal);
        }
    }
}

BPlusNode *BPlusTree::findParent(BPlusNode *cursor, BPlusNode *child) {
    BPlusNode *parent;
    if (cursor->IS_LEAF || (cursor->ptr[0])->IS_LEAF) return nullptr;
    for (int i = 0; i < cursor->size + 1; i++) {
        if (cursor->ptr[i] == child) {
            parent = cursor;
            return parent;
        } else {
            parent = findParent(cursor->ptr[i], child);
            if (parent != nullptr) return parent;
        }
    }
    return parent;
}

void BPlusTree::draw(int startX, int startY) {
    if (root != nullptr) root->draw(startX, startY, startX / 2);
}

void BPlusNode::draw(int x, int y, int offsetX) {
    int cellWidth = 40;
    int boxHeight = 30;
    int totalWidth = size * cellWidth;
    int nodeLeftX = x - (totalWidth / 2);

    // Color distinto para diferenciar hojas (Amarillo) de nodos guía internos (Blanco)
    Color bgColor = IS_LEAF ? LIGHTGRAY : RAYWHITE;
    
    DrawRectangle(nodeLeftX, y, totalWidth, boxHeight, bgColor);
    DrawRectangleLines(nodeLeftX, y, totalWidth, boxHeight, BLACK);

    for (int i = 0; i < size; i++) {
        std::string text = std::to_string(key[i]);
        int textX = nodeLeftX + (i * cellWidth) + (cellWidth / 2) - (MeasureText(text.c_str(), 16) / 2);
        DrawText(text.c_str(), textX, y + 7, 16, MAROON);

        if (i < size - 1) {
            DrawLine(nodeLeftX + (i + 1) * cellWidth, y, nodeLeftX + (i + 1) * cellWidth, y + boxHeight, BLACK);
        }
    }

    // Dibujar lista enlazada si es hoja (Línea verde hacia la derecha)
    if (IS_LEAF && next != nullptr) {
        int nextX = x + offsetX * 2; // Posición aproximada del siguiente nodo
        DrawLine(nodeLeftX + totalWidth, y + (boxHeight/2), nextX - (next->size * cellWidth / 2), y + (boxHeight/2), DARKGREEN);
        DrawCircle(nodeLeftX + totalWidth, y + (boxHeight/2), 3, DARKGREEN); // Punto de conexión
    }

    // Dibujar aristas a los hijos si NO es hoja
    if (!IS_LEAF) {
        for (int i = 0; i <= size; i++) {
            // Dividir el espacio equitativamente para los hijos
            int divisor = (size > 0) ? size : 1;
            int childX = x - offsetX + (i * (offsetX * 2) / divisor);
            int childY = y + 100;
            
            DrawLine(x, y + boxHeight, childX, childY, DARKBLUE);
            ptr[i]->draw(childX, childY, offsetX * 0.45);
        }
    }
}