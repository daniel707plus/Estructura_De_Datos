#ifndef BPLUS_H
#define BPLUS_H

// Nodo del Árbol B+
class BPlusNode {
    bool IS_LEAF;
    int *key;
    int size;
    BPlusNode **ptr;
    BPlusNode *next; // ¡La magia del B+! Conecta las hojas.

public:
    BPlusNode();
    void draw(int x, int y, int offsetX);
    friend class BPlusTree;
};

// Clase Árbol B+
class BPlusTree {
    BPlusNode *root;
    void insertInternal(int, BPlusNode *, BPlusNode *);
    BPlusNode *findParent(BPlusNode *, BPlusNode *);

public:
    BPlusTree();
    void insert(int);
    void draw(int startX, int startY);
};

#endif