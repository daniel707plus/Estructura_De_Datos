#include "raylib.h"
#include "bplus.h" // Incluimos el Árbol B+

//g++ main.cpp bplus.cpp -o arbol_bplus.exe -L. -lraylib -lopengl32 -lgdi32 -lwinmm
//.\arbol_bplus.exe

int main() {
    InitWindow(100, 100, "Inicializando..."); 
    int screenWidth = GetMonitorWidth(0);   
    int screenHeight = GetMonitorHeight(0);
    CloseWindow(); 

    int windowWidth = screenWidth - 100;
    int windowHeight = screenHeight - 150;
    InitWindow(windowWidth, windowHeight, "Arbol B+ Grafico con Raylib");
    SetTargetFPS(60);

    BPlusTree tree; 
    
    // Estos valores forzarán divisiones y mostrarán la lista enlazada
    int valores[] = {5, 15, 25, 35, 45, 55, 65, 75, 85, 95};
    for(int val : valores) {
        tree.insert(val);
    }

    int startX = windowWidth / 2;
    int startY = 50;

    while (!WindowShouldClose()) {
        BeginDrawing();
        ClearBackground(RAYWHITE); 

        DrawText("ARBOL B+ (Nodos guía en blanco, Hojas con datos en gris conectadas por verde)", 20, 20, 20, DARKGRAY);
        
        // Dibujar el árbol B+
        tree.draw(startX, startY);

        EndDrawing();
    }

    CloseWindow();
    return 0;
}