#include "TerminalControlador.h"

TerminalControlador::TerminalControlador(SistemaArchivos* m, ConsolaVista* v) {
    modelo = m;
    vista = v;
}

void TerminalControlador::parsearEntrada(std::string entrada, std::string* comando, std::string* arg1, std::string* arg2) {
    size_t pos1 = entrada.find(' ');
    if (pos1 == std::string::npos) {
        *comando = entrada;
        *arg1 = "";
        *arg2 = "";
        return;
    }
    
    *comando = entrada.substr(0, pos1);
    std::string resto = entrada.substr(pos1 + 1);
    
    size_t pos2 = resto.find(' ');
    if (pos2 == std::string::npos) {
        *arg1 = resto;
        *arg2 = "";
    } else {
        *arg1 = resto.substr(0, pos2);
        *arg2 = resto.substr(pos2 + 1);
    }
}

void TerminalControlador::iniciar() {
    std::string user, pass, pass2;
    bool autenticado = false;

    // --- PANTALLA DE BIENVENIDA AL ESTILO UBUNTU SERVER ---
    vista->mostrarMensaje("\nWelcome to Joshep_Estructura_De_Datos Server (Kernel 6.12.0-generic-amd64)");
    vista->mostrarMensaje("* Documentation:  https://help.ubuntu.com");
    vista->mostrarMensaje("* Support:        https://Joshep_SO.com/pro\n");
    vista->mostrarMensaje("System loads: 100%.\n");

    // --- PRIMER ARRANQUE: REGISTRO INICIAL DE USUARIO ---
    // Si no hay usuarios en el sistema, el operador debe crear las credenciales
    // con las que luego iniciara sesion.
    if (modelo->cantidadUsuarios() == 0) {
        vista->mostrarMensaje("== Primera inicializacion del sistema ==");
        vista->mostrarMensaje("No existen usuarios registrados. Cree la cuenta inicial.\n");

        while (true) {
            vista->mostrarMensaje("Nuevo usuario: ");
            user = vista->leerEntrada();
            if (user.empty()) {
                vista->mostrarError("El nombre de usuario no puede estar vacio.");
                continue;
            }

            vista->mostrarMensaje("Contrasena: ");
            pass = vista->leerEntrada();
            vista->mostrarMensaje("Confirme la contrasena: ");
            pass2 = vista->leerEntrada();

            if (pass != pass2) {
                vista->mostrarError("Las contrasenas no coinciden. Intente de nuevo.\n");
                continue;
            }
            if (pass.empty()) {
                vista->mostrarError("La contrasena no puede estar vacia.");
                continue;
            }

            modelo->registrarUsuario(user, pass);
            vista->mostrarMensaje("Usuario '" + user + "' registrado correctamente.\n");
            break;
        }
    }

    // --- PANTALLA DE LOGIN (solo autenticacion) ---
    while (!autenticado) {
        vista->mostrarMensaje("simulador-server login: ");
        user = vista->leerEntrada();

        vista->mostrarMensaje("Password: ");
        pass = vista->leerEntrada();

        if (modelo->autenticar(user, pass)) {
            autenticado = true;
            vista->mostrarMensaje("\nLogin successful! Type 'ayuda' to explore commands.\n");
        } else {
            vista->mostrarError("Login incorrect.\n");
        }
    }

    // --- INTÉRPRETE DE COMANDOS DEL SISTEMA ---
    bool ejecutando = true;
    std::string entrada, comando, arg1, arg2;

    while (ejecutando) {
        vista->mostrarPrompt(modelo->getUsuarioActual(), modelo->obtenerRutaActual());
        entrada = vista->leerEntrada();
        if (entrada.empty()) continue;

        parsearEntrada(entrada, &comando, &arg1, &arg2);

        if (comando == "salir" || comando == "exit") {
            ejecutando = false;
        }
        else if (comando == "ayuda" || comando == "help") {
            vista->mostrarAyuda();
        }
        else if (comando == "limpiar" || comando == "clear" || comando == "cls") {
            vista->limpiarPantalla();
        }
        else if (comando == "crearcarp" || comando == "mkdir") {
            if (arg1 == "") vista->mostrarError("Debe especificar la ruta de la carpeta.");
            else if (!modelo->crearCarpeta(arg1)) vista->mostrarError("Ruta destino inaccesible.");
        } 
        else if (comando == "eliminarcarp" || comando == "rmdir") {
            if (arg1 == "") vista->mostrarError("Debe especificar la ruta.");
            else if (!modelo->eliminarCarpeta(arg1)) vista->mostrarError("No se pudo eliminar el directorio.");
        } 
        else if (comando == "explorar" || comando == "cd") {
            if (arg1 == "") vista->mostrarError("Especifique un destino.");
            else if (!modelo->cambiarDirectorio(arg1)) vista->mostrarError("Ruta no encontrada.");
        } 
        else if (comando == "regresar") {
            if (!modelo->regresarDirectorio()) vista->mostrarError("Se encuentra en el directorio raiz.");
        } 
        else if (comando == "ruta" || comando == "pwd") {
            vista->mostrarMensaje(modelo->obtenerRutaActual());
        } 
        else if (comando == "listar" || comando == "ls") {
            modelo->listarDirectorio();
        } 
        else if (comando == "creararch" || comando == "touch") {
            if (arg1 == "") vista->mostrarError("Especifique el nombre o ruta del archivo.");
            else if (!modelo->crearArchivo(arg1)) vista->mostrarError("Ruta invalida.");
        } 
        else if (comando == "eliminararch" || comando == "rm") {
            if (arg1 == "") vista->mostrarError("Especifique la ruta del archivo.");
            else if (!modelo->eliminarArchivo(arg1)) vista->mostrarError("Archivo no hallado.");
        }
        else if (comando == "escribir") {
            if (arg1 == "") vista->mostrarError("Falta la ruta del archivo.");
            else if (arg2 == "") vista->mostrarError("Falta el texto.");
            else if (!modelo->escribirArchivo(arg1, arg2)) vista->mostrarError("No se pudo escribir.");
        }
        else if (comando == "leer" || comando == "cat") {
            if (arg1 == "") vista->mostrarError("Falta la ruta.");
            else {
                bool encontrado = false;
                std::string contenido = modelo->leerArchivo(arg1, &encontrado);
                if (encontrado) {
                    vista->mostrarMensaje("=== " + arg1 + " ===");
                    if (contenido.empty()) vista->mostrarMensaje("(Vacio)");
                    else vista->mostrarMensaje(contenido);
                    vista->mostrarMensaje("==============");
                } else {
                    vista->mostrarError("Archivo no encontrado.");
                }
            }
        }
        else if (comando == "arbol" || comando == "tree") {
            modelo->mostrarArbol();
        } 
        else {
            vista->mostrarError("Comando invalido: " + comando);
        }
    }
}