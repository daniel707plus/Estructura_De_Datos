#ifndef TERMINAL_CONTROLADOR_H
#define TERMINAL_CONTROLADOR_H

#include "../model/SistemaArchivos.h"
#include "../view/ConsolaVista.h"

class TerminalControlador {
private:
    SistemaArchivos* modelo;
    ConsolaVista* vista;

    void parsearEntrada(std::string entrada, std::string* comando, std::string* arg1, std::string* arg2);

public:
    TerminalControlador(SistemaArchivos* m, ConsolaVista* v);
    void iniciar();
};

#endif