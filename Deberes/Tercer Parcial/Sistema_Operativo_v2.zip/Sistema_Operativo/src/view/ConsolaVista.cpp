#include "ConsolaVista.h"
#include <iostream>

void ConsolaVista::mostrarMensaje(std::string mensaje) {
    std::cout << mensaje << std::endl;
}

void ConsolaVista::mostrarError(std::string error) {
    std::cout << "Error: " << error << std::endl;
}

void ConsolaVista::mostrarPrompt(std::string usuario, std::string ruta) {
    std::cout << usuario << "@simulador:" << ruta << "$ ";
}

void ConsolaVista::limpiarPantalla() {
    // Secuencia ANSI: borra toda la pantalla (\033[2J) y lleva el cursor al inicio (\033[H).
    // Funciona en Linux, macOS y terminales modernas de Windows (Terminal, VS Code, ConEmu).
    std::cout << "\033[2J\033[H";
}

std::string ConsolaVista::leerEntrada() {
    std::string entrada;
    std::getline(std::cin, entrada);
    return entrada;
}

void ConsolaVista::mostrarAyuda() {
    std::cout << "\\n--- SISTEMA OPERATIVO SIMULADO (CON LOGIN Y RUTAS COMPLEJAS) ---\n";
    std::cout << "crearcarp <ruta>     : Crea una carpeta (ej: crearcarp home/user o /var/log)\n";
    std::cout << "eliminarcarp <ruta>  : Elimina una carpeta de forma recursiva\n";
    std::cout << "explorar <ruta>      : Cambia de directorio (ej: explorar /home/user o cd ..)\n";
    std::cout << "regresar             : Sube una carpeta atras (cd ..)\n";
    std::cout << "ruta                 : Muestra el directorio de trabajo (pwd)\n";
    std::cout << "listar               : Lista el contenido de la carpeta actual (ls)\n";
    std::cout << "creararch <ruta>     : Crea un archivo vacio (touch)\n";
    std::cout << "eliminararch <ruta>  : Elimina un archivo permanentemente (rm)\n";
    std::cout << "escribir <ruta> <txt>: Escribe texto en un archivo\n";
    std::cout << "leer <ruta>          : Lee y muestra el contenido del archivo\n";
    std::cout << "arbol                : Grafica la estructura de directorios (tree)\n";
    std::cout << "ayuda                : Despliega este menu informativo\n";
    std::cout << "salir                : Cierra la sesion y la terminal\n";
    std::cout << "-------------------------------------------------------------------------\n";
}