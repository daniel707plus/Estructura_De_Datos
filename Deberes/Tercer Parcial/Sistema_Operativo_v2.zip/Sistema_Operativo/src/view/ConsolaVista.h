#ifndef CONSOLA_VISTA_H
#define CONSOLA_VISTA_H

#include <string>

class ConsolaVista {
public:
    void mostrarMensaje(std::string mensaje);
    void mostrarError(std::string error);
    void mostrarPrompt(std::string usuario, std::string ruta);
    void limpiarPantalla();
    std::string leerEntrada();
    void mostrarAyuda();
};

#endif