#ifndef NODOS_H
#define NODOS_H

#include <string>

// Nodo para la lista enlazada simple de Usuarios (Login estilo Ubuntu)
class NodoUsuario {
private:
    std::string nombreUsuario;
    std::string contrasena;
    NodoUsuario* siguiente;

    // El modelo necesita acceso directo para manipular la lista enlazada
    friend class SistemaArchivos;

public:
    NodoUsuario(std::string user, std::string pass) {
        nombreUsuario = user;
        contrasena = pass;
        siguiente = nullptr;
    }
};

// Nodo para Archivos (Lista simple enlazada con Contenido - Nivel 1)
class NodoArchivo {
private:
    std::string nombre;
    std::string contenido;
    int tamano;
    NodoArchivo* siguiente;

    friend class SistemaArchivos;

public:
    NodoArchivo(std::string nom) {
        nombre = nom;
        contenido = "";
        tamano = 0;
        siguiente = nullptr;
    }
};

// Nodo para Carpetas (Árbol N-ario: Primer hijo / Siguiente hermano)
class NodoCarpeta {
private:
    std::string nombre;
    NodoCarpeta* padre;
    NodoCarpeta* primeraSubcarpeta;
    NodoCarpeta* siguienteHermana;
    NodoArchivo* primerArchivo;

    friend class SistemaArchivos;

public:
    NodoCarpeta(std::string nom, NodoCarpeta* p) {
        nombre = nom;
        padre = p;
        primeraSubcarpeta = nullptr;
        siguienteHermana = nullptr;
        primerArchivo = nullptr;
    }
};

#endif
