#ifndef SISTEMA_ARCHIVOS_H
#define SISTEMA_ARCHIVOS_H

#include "Nodos.h"
#include <string>

class SistemaArchivos {
private:
    NodoCarpeta* raiz;
    NodoCarpeta* actual;
    NodoUsuario* primerUsuario; // Cabeza de la lista de usuarios
    std::string usuarioActual;  // Almacena el usuario con sesión activa

    // Métodos privados y motores de rutas complejas (Nivel 4)
    void liberarMemoria(NodoCarpeta* carpeta);
    void imprimirArbol(NodoCarpeta* carpeta, std::string prefijo);
    NodoCarpeta* resolverRuta(std::string ruta);
    void separarRutaYNombre(std::string rutaCompleta, std::string* rutaDir, std::string* nombreDestino);

public:
    SistemaArchivos();
    ~SistemaArchivos();

    // Gestión de Autenticación
    bool registrarUsuario(std::string user, std::string pass);
    bool autenticar(std::string user, std::string pass);
    bool existeUsuario(std::string user);
    int cantidadUsuarios();
    std::string getUsuarioActual();

    // Comandos del Sistema Operativo con soporte de rutas
    bool crearCarpeta(std::string rutaCompleta);
    bool eliminarCarpeta(std::string rutaCompleta);
    bool cambiarDirectorio(std::string rutaCompleta);
    bool regresarDirectorio();
    std::string obtenerRutaActual();
    void listarDirectorio();
    bool crearArchivo(std::string rutaCompleta);
    bool eliminarArchivo(std::string rutaCompleta);
    void mostrarArbol();
    
    // Lectura y Escritura (Nivel 1)
    bool escribirArchivo(std::string rutaCompleta, std::string texto);
    std::string leerArchivo(std::string rutaCompleta, bool* encontrado);
};

#endif