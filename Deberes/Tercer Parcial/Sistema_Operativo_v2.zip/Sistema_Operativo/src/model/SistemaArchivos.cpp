#include "SistemaArchivos.h"
#include <iostream>

SistemaArchivos::SistemaArchivos() {
    raiz = new NodoCarpeta("/", nullptr);
    actual = raiz;
    primerUsuario = nullptr;
    usuarioActual = "";
    // La lista de usuarios arranca vacia: se llena desde fuera (main o controlador)
    // segun las credenciales que el propio usuario digite.
}

SistemaArchivos::~SistemaArchivos() {
    liberarMemoria(raiz);
    
    // Liberación estricta de la lista de usuarios mediante punteros
    NodoUsuario* usrAct = primerUsuario;
    while (usrAct != nullptr) {
        NodoUsuario* aBorrar = usrAct;
        usrAct = usrAct->siguiente;
        delete aBorrar;
    }
}

void SistemaArchivos::liberarMemoria(NodoCarpeta* carpeta) {
    if (carpeta == nullptr) return;

    NodoArchivo* archActual = carpeta->primerArchivo;
    while (archActual != nullptr) {
        NodoArchivo* aBorrar = archActual;
        archActual = archActual->siguiente;
        delete aBorrar;
    }

    NodoCarpeta* subActual = carpeta->primeraSubcarpeta;
    while (subActual != nullptr) {
        NodoCarpeta* cBorrar = subActual;
        subActual = subActual->siguienteHermana;
        liberarMemoria(cBorrar);
    }
    delete carpeta;
}

// =========================================================================
// CONTROL DE USUARIOS Y AUTENTICACIÓN
// =========================================================================
bool SistemaArchivos::registrarUsuario(std::string user, std::string pass) {
    NodoUsuario* nuevo = new NodoUsuario(user, pass);
    if (primerUsuario == nullptr) {
        primerUsuario = nuevo;
    } else {
        NodoUsuario* temp = primerUsuario;
        while (temp->siguiente != nullptr) {
            if (temp->nombreUsuario == user) {
                delete nuevo;
                return false;
            }
            temp = temp->siguiente;
        }
        if (temp->nombreUsuario == user) {
            delete nuevo;
            return false;
        }
        temp->siguiente = nuevo;
    }
    return true;
}

bool SistemaArchivos::autenticar(std::string user, std::string pass) {
    NodoUsuario* temp = primerUsuario;
    while (temp != nullptr) {
        if (temp->nombreUsuario == user && temp->contrasena == pass) {
            usuarioActual = user;
            return true;
        }
        temp = temp->siguiente;
    }
    return false;
}

std::string SistemaArchivos::getUsuarioActual() {
    return usuarioActual;
}

bool SistemaArchivos::existeUsuario(std::string user) {
    NodoUsuario* temp = primerUsuario;
    while (temp != nullptr) {
        if (temp->nombreUsuario == user) return true;
        temp = temp->siguiente;
    }
    return false;
}

int SistemaArchivos::cantidadUsuarios() {
    int n = 0;
    NodoUsuario* temp = primerUsuario;
    while (temp != nullptr) {
        n++;
        temp = temp->siguiente;
    }
    return n;
}

// =========================================================================
// MOTOR DE RESOLUCIÓN DE RUTAS COMPLEJAS (Nivel 4) - Sin usar []
// =========================================================================
NodoCarpeta* SistemaArchivos::resolverRuta(std::string ruta) {
    if (ruta.empty()) return actual;

    NodoCarpeta* temp = actual;
    size_t inicio = 0;

    // Si comienza con '/', es una ruta absoluta desde la raíz
    if (ruta.substr(0, 1) == "/") {
        temp = raiz;
        inicio = 1;
    }

    std::string resto = ruta.substr(inicio);
    
    while (!resto.empty()) {
        size_t posSlash = resto.find('/');
        std::string segmento = (posSlash == std::string::npos) ? resto : resto.substr(0, posSlash);

        if (segmento == "..") {
            if (temp->padre != nullptr) {
                temp = temp->padre;
            }
        } else if (segmento != "." && !segmento.empty()) {
            NodoCarpeta* sub = temp->primeraSubcarpeta;
            bool encontrado = false;
            while (sub != nullptr) {
                if (sub->nombre == segmento) {
                    temp = sub;
                    encontrado = true;
                    break;
                }
                sub = sub->siguienteHermana;
            }
            if (!encontrado) return nullptr; 
        }

        if (posSlash == std::string::npos) break;
        else resto = resto.substr(posSlash + 1);
    }
    return temp;
}

void SistemaArchivos::separarRutaYNombre(std::string rutaCompleta, std::string* rutaDir, std::string* nombreDestino) {
    size_t lastSlash = rutaCompleta.rfind('/');
    if (lastSlash == std::string::npos) {
        *rutaDir = "";
        *nombreDestino = rutaCompleta;
    } else if (lastSlash == 0) {
        *rutaDir = "/";
        *nombreDestino = rutaCompleta.substr(1);
    } else {
        *rutaDir = rutaCompleta.substr(0, lastSlash);
        *nombreDestino = rutaCompleta.substr(lastSlash + 1);
    }
}

// =========================================================================
// IMPLEMENTACIÓN DE COMANDOS DEL FILER SYSTEM
// =========================================================================
bool SistemaArchivos::crearCarpeta(std::string rutaCompleta) {
    std::string rutaDir, nombre;
    separarRutaYNombre(rutaCompleta, &rutaDir, &nombre);
    
    NodoCarpeta* destino = rutaDir.empty() ? actual : resolverRuta(rutaDir);
    if (destino == nullptr || nombre.empty()) return false;

    NodoCarpeta* nueva = new NodoCarpeta(nombre, destino);
    if (destino->primeraSubcarpeta == nullptr) {
        destino->primeraSubcarpeta = nueva;
    } else {
        NodoCarpeta* temp = destino->primeraSubcarpeta;
        while (temp->siguienteHermana != nullptr) {
            temp = temp->siguienteHermana;
        }
        temp->siguienteHermana = nueva;
    }
    return true;
}

bool SistemaArchivos::crearArchivo(std::string rutaCompleta) {
    std::string rutaDir, nombre;
    separarRutaYNombre(rutaCompleta, &rutaDir, &nombre);
    
    NodoCarpeta* destino = rutaDir.empty() ? actual : resolverRuta(rutaDir);
    if (destino == nullptr || nombre.empty()) return false;

    NodoArchivo* nuevo = new NodoArchivo(nombre);
    if (destino->primerArchivo == nullptr) {
        destino->primerArchivo = nuevo;
    } else {
        NodoArchivo* temp = destino->primerArchivo;
        while (temp->siguiente != nullptr) {
            temp = temp->siguiente;
        }
        temp->siguiente = nuevo;
    }
    return true;
}

bool SistemaArchivos::cambiarDirectorio(std::string rutaCompleta) {
    NodoCarpeta* destino = resolverRuta(rutaCompleta);
    if (destino != nullptr) {
        actual = destino;
        return true;
    }
    return false;
}

bool SistemaArchivos::escribirArchivo(std::string rutaCompleta, std::string texto) {
    std::string rutaDir, nombre;
    separarRutaYNombre(rutaCompleta, &rutaDir, &nombre);
    
    NodoCarpeta* destino = rutaDir.empty() ? actual : resolverRuta(rutaDir);
    if (destino == nullptr) return false;

    NodoArchivo* temp = destino->primerArchivo;
    while (temp != nullptr) {
        if (temp->nombre == nombre) {
            temp->contenido += texto + "\n";
            temp->tamano = temp->contenido.length();
            return true;
        }
        temp = temp->siguiente;
    }
    return false;
}

std::string SistemaArchivos::leerArchivo(std::string rutaCompleta, bool* encontrado) {
    std::string rutaDir, nombre;
    separarRutaYNombre(rutaCompleta, &rutaDir, &nombre);
    
    NodoCarpeta* destino = rutaDir.empty() ? actual : resolverRuta(rutaDir);
    if (destino == nullptr) {
        *encontrado = false;
        return "";
    }

    NodoArchivo* temp = destino->primerArchivo;
    while (temp != nullptr) {
        if (temp->nombre == nombre) {
            *encontrado = true;
            return temp->contenido;
        }
        temp = temp->siguiente;
    }
    *encontrado = false;
    return "";
}

bool SistemaArchivos::eliminarArchivo(std::string rutaCompleta) {
    std::string rutaDir, nombre;
    separarRutaYNombre(rutaCompleta, &rutaDir, &nombre);
    
    NodoCarpeta* destino = rutaDir.empty() ? actual : resolverRuta(rutaDir);
    if (destino == nullptr) return false;

    NodoArchivo* temp = destino->primerArchivo;
    NodoArchivo* anterior = nullptr;

    while (temp != nullptr) {
        if (temp->nombre == nombre) {
            if (anterior == nullptr) {
                destino->primerArchivo = temp->siguiente;
            } else {
                anterior->siguiente = temp->siguiente;
            }
            delete temp;
            return true;
        }
        anterior = temp;
        temp = temp->siguiente;
    }
    return false;
}

bool SistemaArchivos::eliminarCarpeta(std::string rutaCompleta) {
    std::string rutaDir, nombre;
    separarRutaYNombre(rutaCompleta, &rutaDir, &nombre);
    
    NodoCarpeta* destino = rutaDir.empty() ? actual : resolverRuta(rutaDir);
    if (destino == nullptr) return false;

    NodoCarpeta* temp = destino->primeraSubcarpeta;
    NodoCarpeta* anterior = nullptr;

    while (temp != nullptr) {
        if (temp->nombre == nombre) {
            if (anterior == nullptr) {
                destino->primeraSubcarpeta = temp->siguienteHermana;
            } else {
                anterior->siguienteHermana = temp->siguienteHermana;
            }
            liberarMemoria(temp);
            return true;
        }
        anterior = temp;
        temp = temp->siguienteHermana;
    }
    return false;
}

void SistemaArchivos::listarDirectorio() {
    NodoCarpeta* sub = actual->primeraSubcarpeta;
    while (sub != nullptr) {
        std::cout << "[DIR]  " << sub->nombre << "\n";
        sub = sub->siguienteHermana;
    }

    NodoArchivo* arch = actual->primerArchivo;
    while (arch != nullptr) {
        std::cout << "[FILE] " << arch->nombre << " (" << arch->tamano << " bytes)\n";
        arch = arch->siguiente;
    }
}

bool SistemaArchivos::regresarDirectorio() {
    if (actual->padre != nullptr) {
        actual = actual->padre;
        return true;
    }
    return false;
}

std::string SistemaArchivos::obtenerRutaActual() {
    std::string ruta = "";
    NodoCarpeta* temp = actual;
    while (temp != nullptr) {
        if (temp->nombre != "/") {
            // Línea corregida: se eliminó "user@simulador:"
            ruta = "/" + temp->nombre + ruta; 
        }
        temp = temp->padre;
    }
    return ruta.empty() ? "/" : ruta;
}

void SistemaArchivos::imprimirArbol(NodoCarpeta* carpeta, std::string prefijo) {
    if (carpeta == nullptr) return;

    std::cout << prefijo << "+-- " << carpeta->nombre << "\n";
    std::string nuevoPrefijo = prefijo + "    ";
    
    NodoCarpeta* sub = carpeta->primeraSubcarpeta;
    while (sub != nullptr) {
        imprimirArbol(sub, nuevoPrefijo);
        sub = sub->siguienteHermana;
    }

    NodoArchivo* arch = carpeta->primerArchivo;
    while (arch != nullptr) {
        std::cout << nuevoPrefijo << "- " << arch->nombre << " (" << arch->tamano << "b)\n";
        arch = arch->siguiente;
    }
}

void SistemaArchivos::mostrarArbol() {
    imprimirArbol(actual, "");
}