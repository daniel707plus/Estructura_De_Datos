

// g++ src/main.cpp src/model/SistemaArchivos.cpp src/view/ConsolaVista.cpp src/controller/TerminalControlador.cpp -o build/simulador
//.\build\simulador.exe  

#include "model/SistemaArchivos.h"
#include "view/ConsolaVista.h"
#include "controller/TerminalControlador.h"

int main(int argc, char** argv) {
    SistemaArchivos* modelo = new SistemaArchivos();
    ConsolaVista* vista = new ConsolaVista();
    TerminalControlador* controlador = new TerminalControlador(modelo, vista);
    
    
    controlador->iniciar();
    
    
    delete controlador;
    delete vista;
    delete modelo;

    return 0;
}