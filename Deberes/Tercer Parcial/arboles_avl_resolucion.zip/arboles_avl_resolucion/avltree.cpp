#include "avltree.h"
#include "raylib.h"
#include <string>

// --- Implementación de AVLNode ---
AVLNode::AVLNode(int val) {
    data = val;
    height = 1; // Un nodo nuevo siempre se agrega en el fondo, su altura inicial es 1
    left = nullptr;
    right = nullptr;
}

void AVLNode::draw(int x, int y, int offsetX) {
    // 1. Dibujar líneas a los hijos
    if (left != nullptr) {
        int childX = x - offsetX;
        int childY = y + 80;
        DrawLine(x, y, childX, childY, DARKGRAY);
        left->draw(childX, childY, offsetX / 2);
    }
    
    if (right != nullptr) {
        int childX = x + offsetX;
        int childY = y + 80;
        DrawLine(x, y, childX, childY, DARKGRAY);
        right->draw(childX, childY, offsetX / 2);
    }

    // 2. Dibujar el nodo (Círculo Azul oscuro para el AVL)
    DrawCircle(x, y, 20, DARKBLUE);
    DrawCircleLines(x, y, 20, RAYWHITE); 

    // 3. Dibujar el valor
    std::string text = std::to_string(data);
    int textWidth = MeasureText(text.c_str(), 16);
    DrawText(text.c_str(), x - (textWidth / 2), y - 8, 16, RAYWHITE);
}

// --- Implementación de AVLTree ---
AVLTree::AVLTree() {
    root = nullptr;
}

int AVLTree::height(AVLNode *N) {
    if (N == nullptr) return 0;
    return N->height;
}

int AVLTree::max(int a, int b) {
    return (a > b) ? a : b;
}

int AVLTree::getBalance(AVLNode *N) {
    if (N == nullptr) return 0;
    return height(N->left) - height(N->right);
}

// Rotación simple a la derecha
AVLNode* AVLTree::rightRotate(AVLNode *y) {
    AVLNode *x = y->left;
    AVLNode *T2 = x->right;

    x->right = y;
    y->left = T2;

    y->height = max(height(y->left), height(y->right)) + 1;
    x->height = max(height(x->left), height(x->right)) + 1;

    return x;
}

// Rotación simple a la izquierda
AVLNode* AVLTree::leftRotate(AVLNode *x) {
    AVLNode *y = x->right;
    AVLNode *T2 = y->left;

    y->left = x;
    x->right = T2;

    x->height = max(height(x->left), height(x->right)) + 1;
    y->height = max(height(y->left), height(y->right)) + 1;

    return y;
}

// Inserción recursiva con autobalanceo inmediato
AVLNode* AVLTree::insertNode(AVLNode *node, int val) {
    // 1. Inserción normal de un árbol binario
    if (node == nullptr) return new AVLNode(val);

    if (val < node->data) {
        node->left = insertNode(node->left, val);
    } else if (val > node->data) {
        node->right = insertNode(node->right, val);
    } else {
        return node; // No se permiten duplicados en este AVL básico
    }

    // 2. Actualizar la altura del ancestro actual
    node->height = 1 + max(height(node->left), height(node->right));

    // 3. Obtener el factor de balance para revisar si se desequilibró
    int balance = getBalance(node);

    // Si se desbalanceó, hay 4 casos posibles:

    // Caso Izquierda-Izquierda
    if (balance > 1 && val < node->left->data)
        return rightRotate(node);

    // Caso Derecha-Derecha
    if (balance < -1 && val > node->right->data)
        return leftRotate(node);

    // Caso Izquierda-Derecha
    if (balance > 1 && val > node->left->data) {
        node->left = leftRotate(node->left);
        return rightRotate(node);
    }

    // Caso Derecha-Izquierda
    if (balance < -1 && val < node->right->data) {
        node->right = rightRotate(node->right);
        return leftRotate(node);
    }

    return node;
}

void AVLTree::insert(int val) {
    root = insertNode(root, val);
}

void AVLTree::draw(int startX, int startY) {
    if (root != nullptr) {
        root->draw(startX, startY, startX / 2);
    }
}