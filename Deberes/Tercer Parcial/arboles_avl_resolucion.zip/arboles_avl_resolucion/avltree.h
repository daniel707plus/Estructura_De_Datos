#ifndef AVLTREE_H
#define AVLTREE_H

class AVLNode {
public:
    int data;
    int height; // El AVL necesita saber la altura de cada nodo
    AVLNode *left;
    AVLNode *right;

    AVLNode(int val);
    void draw(int x, int y, int offsetX); 
};

class AVLTree {
private:
    AVLNode *root;

    // Funciones internas basadas en punteros puros
    int height(AVLNode *N);
    int getBalance(AVLNode *N);
    int max(int a, int b);
    
    AVLNode* rightRotate(AVLNode *y);
    AVLNode* leftRotate(AVLNode *x);
    AVLNode* insertNode(AVLNode *node, int val);

public:
    AVLTree();
    void insert(int val);
    void draw(int startX, int startY);
};

#endif