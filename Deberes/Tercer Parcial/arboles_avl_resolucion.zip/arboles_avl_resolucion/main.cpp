#include "raylib.h"
#include "avltree.h" 

//g++ main.cpp avltree.cpp -o arbol_avl.exe -L. -lraylib -lopengl32 -lgdi32 -lwinmm
//.\arbol_avl.exe

int main() {
    InitWindow(100, 100, "Inicializando..."); 
    int screenWidth = GetMonitorWidth(0);   
    int screenHeight = GetMonitorHeight(0);
    CloseWindow(); 

    int windowWidth = screenWidth - 100;
    int windowHeight = screenHeight - 150;
    InitWindow(windowWidth, windowHeight, "Arbol AVL con Raylib");
    SetTargetFPS(60);

    AVLTree tree; 
    
    // --- NUEVA LÓGICA DE INSERCIÓN DINÁMICA ---
    // Tomamos tu ancho de pantalla real (por ejemplo 1920 o 1366)
    int valorActual = screenWidth; 
    
    // Mientras el valor no caiga a 0, seguimos insertando y dividiendo
    while (valorActual > 0) {
        tree.insert(valorActual);
        valorActual = valorActual / 2; // Partimos a la mitad para la siguiente vuelta
    }

    int startX = windowWidth / 2;
    int startY = 80;

    while (!WindowShouldClose()) {
        BeginDrawing();
        ClearBackground(LIGHTGRAY); 

        DrawText("ARBOL AVL (Inserciones dinamicas segun tu resolucion)", 20, 20, 20, DARKGRAY);
        
        tree.draw(startX, startY);

        EndDrawing();
    }

    CloseWindow();
    return 0;
}