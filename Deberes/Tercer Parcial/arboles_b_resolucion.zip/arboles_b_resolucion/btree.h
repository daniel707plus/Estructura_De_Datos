#ifndef BTREE_H
#define BTREE_H

// Declaración de la clase BTree adelantada para que BTreeNode la reconozca
class BTree;

// Estructura del Nodo del Árbol B
class BTreeNode {
    int *keys;
    int t;      
    BTreeNode **C; 
    int n;      
    bool leaf; 

public:
    BTreeNode(int _t, bool _leaf);
    void insertNonFull(int k);
    void splitChild(int i, BTreeNode *y);
    
    // Función para dibujar gráficamente
    void draw(int x, int y, int offsetX); 

    friend class BTree;
};

// Clase Árbol B
class BTree {
    BTreeNode *root;
    int t;

public:
    BTree(int _t);
    void insert(int k);
    void draw(int startX, int startY);
};

#endif