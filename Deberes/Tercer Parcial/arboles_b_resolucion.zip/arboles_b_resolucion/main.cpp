#include "raylib.h"
#include "btree.h" // Incluimos la cabecera de tu árbol

//g++ main.cpp btree.cpp -o arbol_grafico.exe -L. -lraylib -lopengl32 -lgdi32 -lwinmm
//.\arbol_grafico.exe

int main() {
    InitWindow(100, 100, "Inicializando..."); 
    int screenWidth = GetMonitorWidth(0);   
    int screenHeight = GetMonitorHeight(0);
    CloseWindow(); 

    int windowWidth = screenWidth - 100;
    int windowHeight = screenHeight - 150;
    InitWindow(windowWidth, windowHeight, "Arbol B Grafico con Raylib");
    SetTargetFPS(60);

    BTree tree(3); 
    int valores[] = {10, 20, 5, 6, 12, 30, 7, 17, 25, 40, 3, 1, 15, 18, 9, 22, 35};
    for(int val : valores) {
        tree.insert(val);
    }

    int startX = windowWidth / 2;
    int startY = 50;

    while (!WindowShouldClose()) {
        BeginDrawing();
        ClearBackground(LIGHTGRAY); 

        DrawText("ARBOL B GRAFICO (REGLAS DE INSERCION RESPETADAS)", 20, 20, 20, DARKGRAY);
        tree.draw(startX, startY);

        EndDrawing();
    }

    CloseWindow();
    return 0;
}