#include "btree.h"
#include "raylib.h"
#include <string>

// --- Implementación de BTree ---

BTree::BTree(int _t) { 
    root = nullptr; 
    t = _t; 
}

void BTree::insert(int k) {
    if (root == nullptr) {
        root = new BTreeNode(t, true);
        root->keys[0] = k;
        root->n = 1;
    } else {
        if (root->n == 2*t - 1) {
            BTreeNode *s = new BTreeNode(t, false);
            s->C[0] = root;
            s->splitChild(0, root);
            int i = 0;
            if (s->keys[0] < k) i++;
            s->C[i]->insertNonFull(k);
            root = s;
        } else {
            root->insertNonFull(k);
        }
    }
}

void BTree::draw(int startX, int startY) { 
    if (root != nullptr) root->draw(startX, startY, startX / 2); 
}


// --- Implementación de BTreeNode ---

BTreeNode::BTreeNode(int _t, bool _leaf) {
    t = _t;
    leaf = _leaf;
    keys = new int[2*t - 1];
    C = new BTreeNode *[2*t];
    n = 0;
}

void BTreeNode::insertNonFull(int k) {
    int i = n - 1;
    if (leaf) {
        while (i >= 0 && keys[i] > k) {
            keys[i+1] = keys[i];
            i--;
        }
        keys[i+1] = k;
        n = n + 1;
    } else {
        while (i >= 0 && keys[i] > k) i--;
        if (C[i+1]->n == 2*t - 1) {
            splitChild(i+1, C[i+1]);
            if (keys[i+1] < k) i++;
        }
        C[i+1]->insertNonFull(k);
    }
}

void BTreeNode::splitChild(int i, BTreeNode *y) {
    BTreeNode *z = new BTreeNode(y->t, y->leaf);
    z->n = t - 1;
    for (int j = 0; j < t - 1; j++) z->keys[j] = y->keys[j+t];
    if (!y->leaf) {
        for (int j = 0; j < t; j++) z->C[j] = y->C[j+t];
    }
    y->n = t - 1;
    for (int j = n; j >= i + 1; j--) C[j+1] = C[j];
    C[i+1] = z;
    for (int j = n - 1; j >= i; j--) keys[j+1] = keys[j];
    keys[i] = y->keys[t-1];
    n = n + 1;
}

void BTreeNode::draw(int x, int y, int offsetX) {
    int cellWidth = 40;
    int boxHeight = 30;
    int totalWidth = n * cellWidth;

    int nodeLeftX = x - (totalWidth / 2);
    DrawRectangle(nodeLeftX, y, totalWidth, boxHeight, RAYWHITE);
    DrawRectangleLines(nodeLeftX, y, totalWidth, boxHeight, BLACK);

    for (int i = 0; i < n; i++) {
        std::string text = std::to_string(keys[i]);
        int textX = nodeLeftX + (i * cellWidth) + (cellWidth / 2) - (MeasureText(text.c_str(), 16) / 2);
        DrawText(text.c_str(), textX, y + 7, 16, MAROON);

        if (i < n - 1) {
            DrawLine(nodeLeftX + (i + 1) * cellWidth, y, nodeLeftX + (i + 1) * cellWidth, y + boxHeight, BLACK);
        }
    }

    if (!leaf) {
        for (int i = 0; i <= n; i++) {
            int childX = x - offsetX + (i * (offsetX * 2) / n);
            int childY = y + 100; 
            DrawLine(x, y + boxHeight, childX, childY, DARKBLUE);
            C[i]->draw(childX, childY, offsetX * 0.45); 
        }
    }
}