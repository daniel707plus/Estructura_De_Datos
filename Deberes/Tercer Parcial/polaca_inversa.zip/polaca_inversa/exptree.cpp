#include "exptree.h"
#include "raylib.h"

// --- Implementación del Nodo del Árbol ---
ExpNode::ExpNode(char val) {
    data = val;
    left = nullptr;
    right = nullptr;
}

void ExpNode::draw(int x, int y, int offsetX) {
    if (left != nullptr) {
        int childX = x - offsetX;
        int childY = y + 70;
        DrawLine(x, y, childX, childY, DARKGRAY);
        left->draw(childX, childY, offsetX / 2);
    }
    
    if (right != nullptr) {
        int childX = x + offsetX;
        int childY = y + 70;
        DrawLine(x, y, childX, childY, DARKGRAY);
        right->draw(childX, childY, offsetX / 2);
    }

    // Color: Si es operador, Morado. Si es operando, Verde oscuro.
    bool isOperator = (data == '+' || data == '-' || data == '*' || data == '/');
    Color nodeColor = isOperator ? PURPLE : DARKGREEN;

    DrawCircle(x, y, 20, nodeColor);
    DrawCircleLines(x, y, 20, RAYWHITE); 

    std::string text(1, data); // Convertir char a string para dibujarlo
    int textWidth = MeasureText(text.c_str(), 16);
    DrawText(text.c_str(), x - (textWidth / 2), y - 8, 16, RAYWHITE);
}

// --- Implementación de la Pila de Punteros Puros ---
StackNode::StackNode(ExpNode *node) {
    treeNode = node;
    next = nullptr;
}

void ExpTree::push(ExpNode *node) {
    StackNode *newNode = new StackNode(node);
    newNode->next = top;
    top = newNode;
}

ExpNode* ExpTree::pop() {
    if (top == nullptr) return nullptr;
    ExpNode *res = top->treeNode;
    StackNode *temp = top;
    top = top->next;
    delete temp; // Liberamos la memoria del nodo de la pila
    return res;
}

// --- Implementación del Árbol ---
ExpTree::ExpTree() {
    root = nullptr;
    top = nullptr;
}

// Construye el árbol leyendo la cadena mediante aritmética de punteros (sin [])
void ExpTree::buildTree(const char *postfix) {
    const char *p = postfix; 
    
    while (*p != '\0') { // Mientras el puntero no llegue al final del texto
        if (*p == '+' || *p == '-' || *p == '*' || *p == '/') {
            ExpNode *z = new ExpNode(*p);
            // El orden de pop importa: el primero es el hijo derecho, el segundo el izquierdo
            z->right = pop();
            z->left = pop();
            push(z);
        } else {
            // Si es un número, lo metemos a la pila
            push(new ExpNode(*p));
        }
        p++; // Avanzamos el puntero de memoria al siguiente caracter
    }
    root = pop(); // El último nodo restante es la raíz del árbol
}

void ExpTree::preOrden(ExpNode *node, std::string &res) {
    if (node == nullptr) return;
    res += node->data; res += " ";
    preOrden(node->left, res);
    preOrden(node->right, res);
}

void ExpTree::inOrden(ExpNode *node, std::string &res) {
    if (node == nullptr) return;
    inOrden(node->left, res);
    res += node->data; res += " ";
    inOrden(node->right, res);
}

void ExpTree::postOrden(ExpNode *node, std::string &res) {
    if (node == nullptr) return;
    postOrden(node->left, res);
    postOrden(node->right, res);
    res += node->data; res += " ";
}

std::string ExpTree::getPreOrden() { std::string r = ""; preOrden(root, r); return r; }
std::string ExpTree::getInOrden() { std::string r = ""; inOrden(root, r); return r; }
std::string ExpTree::getPostOrden() { std::string r = ""; postOrden(root, r); return r; }

void ExpTree::draw(int startX, int startY) {
    if (root != nullptr) root->draw(startX, startY, startX / 2);
}