#include "raylib.h"
#include "exptree.h" 
#include <string>

//g++ main.cpp exptree.cpp -o arbol_expresiones.exe -L. -lraylib -lopengl32 -lgdi32 -lwinmm
//.\arbol_expresiones

int main() {
    InitWindow(100, 100, "Inicializando..."); 
    int screenWidth = GetMonitorWidth(0);   
    int screenHeight = GetMonitorHeight(0);
    CloseWindow(); 

    int windowWidth = screenWidth - 100;
    int windowHeight = screenHeight - 150;
    InitWindow(windowWidth, windowHeight, "Arbol de Expresiones y Recorridos");
    SetTargetFPS(60);

    ExpTree tree; 
    
    // Pasamos un puntero char literal con la expresión postfija (Polaca Inversa)
    // Esto equivale a la expresión tradicional: (5 + 3) * (8 - 2)
    const char *expresion = "53+82-*";
    tree.buildTree(expresion);

    // Obtenemos los recorridos para mostrarlos en pantalla
    std::string polaca = "Preorden (Polaca): " + tree.getPreOrden();
    std::string infija = "Inorden (Tradicional): " + tree.getInOrden();
    std::string polacaInv = "Postorden (Polaca Inversa): " + tree.getPostOrden();

    int startX = windowWidth / 2;
    int startY = 150; // Bajamos el árbol un poco para dejar espacio al texto

    while (!WindowShouldClose()) {
        BeginDrawing();
        ClearBackground(LIGHTGRAY); 

        // Dibujar los recorridos obtenidos
        DrawText("RECORRIDOS DEL ARBOL DE EXPRESIONES", 20, 20, 22, DARKGRAY);
        DrawText(polaca.c_str(), 20, 60, 20, MAROON);
        DrawText(infija.c_str(), 20, 90, 20, DARKBLUE);
        DrawText(polacaInv.c_str(), 20, 120, 20, DARKGREEN);
        
        // Dibujar el árbol
        tree.draw(startX, startY);

        EndDrawing();
    }

    CloseWindow();
    return 0;
}