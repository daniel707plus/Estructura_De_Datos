#ifndef EXPTREE_H
#define EXPTREE_H

#include <string>

// Nodo del Árbol de Expresiones
class ExpNode {
public:
    char data;
    ExpNode *left;
    ExpNode *right;

    ExpNode(char val);
    void draw(int x, int y, int offsetX); 
};

// Nodo para nuestra propia Pila (Stack) de punteros puros
class StackNode {
public:
    ExpNode *treeNode;
    StackNode *next;

    StackNode(ExpNode *node);
};

// Árbol de Expresiones
class ExpTree {
private:
    ExpNode *root;
    StackNode *top; // Puntero al tope de nuestra pila

    // Funciones de la Pila pura
    void push(ExpNode *node);
    ExpNode* pop();

    // Recorridos recursivos puros
    void preOrden(ExpNode *node, std::string &res);
    void inOrden(ExpNode *node, std::string &res);
    void postOrden(ExpNode *node, std::string &res);

public:
    ExpTree();
    void buildTree(const char *postfix); // Recibe un puntero a char, sin arreglos
    
    std::string getPreOrden();
    std::string getInOrden();
    std::string getPostOrden();
    
    void draw(int startX, int startY);
};

#endif