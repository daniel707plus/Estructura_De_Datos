#include <windows.h>
#include <iostream>
#include <fstream>

using namespace std;

// Punteros globales en lugar de vectores
int* tableroDatos = nullptr;
bool* movimientosValidos = nullptr;
int n = 0;
int cabFila = 0, cabCol = 0;

// --- FUNCIÓN DE PIXELAR CON PUNTEROS ---
void DibujarCaballoPixelado(HDC hdc, int startX, int startY, int tamanoCelda) {
    // Asignación de memoria dinámica para el arreglo del caballo (64 elementos)
    int* caballo = new int[64]{
        0, 0, 1, 1, 0, 0, 0, 0,
        0, 1, 1, 1, 1, 0, 0, 0,
        0, 0, 1, 1, 1, 1, 0, 0,
        0, 0, 0, 1, 1, 0, 0, 0,
        0, 0, 0, 1, 1, 0, 0, 0,
        0, 0, 1, 1, 1, 1, 0, 0,
        0, 1, 1, 1, 1, 1, 1, 0,
        1, 1, 1, 1, 1, 1, 1, 1
    };
    
    int tamanoPixel = tamanoCelda / 8;
    HBRUSH brochaCaballo = CreateSolidBrush(RGB(200, 50, 50)); 
    
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
            // ARITMÉTICA DE PUNTEROS: *(caballo + i * 8 + j)
            if (*(caballo + (i * 8) + j) == 1) {
                RECT p = { startX + (j * tamanoPixel), startY + (i * tamanoPixel),
                           startX + ((j + 1) * tamanoPixel), startY + ((i + 1) * tamanoPixel) };
                FillRect(hdc, &p, brochaCaballo);
            }
        }
    }
    
    DeleteObject(brochaCaballo);
    delete[] caballo; // Liberar memoria del puntero
}

// --- PROCEDIMIENTO DE LA VENTANA ---
LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    switch (uMsg) {
        case WM_PAINT: {
            PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hwnd, &ps);

            int tamanoCelda = 50; 
            int offsetX = 20;     
            int offsetY = 20;    

            HBRUSH brochaBlanca = CreateSolidBrush(RGB(240, 240, 240));
            HBRUSH brochaNegra = CreateSolidBrush(RGB(100, 100, 100));
            HBRUSH brochaVerde = CreateSolidBrush(RGB(50, 200, 50)); 

            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    // Cálculo del índice plano
                    int index = (i * n) + j;
                    
                    RECT rect = { offsetX + (j * tamanoCelda), offsetY + (i * tamanoCelda),
                                  offsetX + ((j + 1) * tamanoCelda), offsetY + ((i + 1) * tamanoCelda) };

                    // ARITMÉTICA DE PUNTEROS para leer datos
                    if (*(movimientosValidos + index)) {
                        FillRect(hdc, &rect, brochaVerde); 
                    } else if (*(tableroDatos + index) == 0) {
                        FillRect(hdc, &rect, brochaBlanca);
                    } else {
                        FillRect(hdc, &rect, brochaNegra);
                    }
                    
                    if (i == cabFila && j == cabCol) {
                        // Repintar fondo bajo el caballo
                        if (*(tableroDatos + index) == 0) FillRect(hdc, &rect, brochaBlanca);
                        else FillRect(hdc, &rect, brochaNegra);
                        
                        DibujarCaballoPixelado(hdc, rect.left, rect.top, tamanoCelda);
                    }
                }
            }

            DeleteObject(brochaBlanca);
            DeleteObject(brochaNegra);
            DeleteObject(brochaVerde);
            EndPaint(hwnd, &ps);
            return 0;
        }
        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;
    }
    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

int main() {
    // 1. Leer archivo para contar elementos (doble pasada para usar punteros puros)
    ifstream archivo("tablero.txt");
    if (!archivo.is_open()) {
        cout << "Error: No se encontro 'tablero.txt'." << endl;
        return 1;
    }

    int totalElementos = 0;
    int valorTmp;
    while (archivo >> valorTmp) {
        totalElementos++;
    }
    
    // Regresar el cursor del archivo al inicio
    archivo.clear();
    archivo.seekg(0, ios::beg);

    // Asignar memoria dinámica a nuestro puntero principal
    tableroDatos = new int[totalElementos];
    
    // Llenar datos usando un puntero auxiliar
    int* pLectura = tableroDatos;
    while (archivo >> valorTmp) {
        *pLectura = valorTmp;
        pLectura++; // Avanzamos el puntero
    }
    archivo.close();

    // Calcular tamaño N del tablero
    while (n * n < totalElementos) n++;

    // 2. Interacción con el usuario
    cout << "--- SIMULADOR CON PUNTEROS PUROS ---" << endl;
    cout << "Tablero de " << n << "x" << n << " detectado." << endl;
    cout << "Ingrese la Fila del caballo (0 a " << n - 1 << "): ";
    cin >> cabFila;
    cout << "Ingrese la Columna del caballo (0 a " << n - 1 << "): ";
    cin >> cabCol;

    if (cabFila < 0 || cabFila >= n || cabCol < 0 || cabCol >= n) {
        cout << "Posicion invalida." << endl;
        delete[] tableroDatos; // Limpieza
        return 1;
    }

    // 3. Lógica de movimientos usando Punteros Dinámicos
    int* movFila = new int[8]{-2, -2, -1, -1, 1, 1, 2, 2};
    int* movCol  = new int[8]{-1, 1, -2, 2, -2, 2, -1, 1};
    
    movimientosValidos = new bool[n * n];
    
    // Inicializar puntero booleano en falso
    for (int i = 0; i < (n * n); i++) {
        *(movimientosValidos + i) = false;
    }

    for (int k = 0; k < 8; k++) {
        // Obtenemos los valores desreferenciando el puntero *(p + k)
        int nuevaFila = cabFila + *(movFila + k);
        int nuevaCol = cabCol + *(movCol + k);
        
        if (nuevaFila >= 0 && nuevaFila < n && nuevaCol >= 0 && nuevaCol < n) {
            // Marcamos true en el índice calculado
            *(movimientosValidos + (nuevaFila * n) + nuevaCol) = true;
        }
    }

    cout << "Abriendo ventana grafica..." << endl;

    // 4. Crear la Ventana
    HINSTANCE hInstance = GetModuleHandle(NULL);
    WNDCLASS wc = {0};
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = "AjedrezPunteros";
    
    RegisterClass(&wc);

    int windowWidth = (n * 50) + 60;
    int windowHeight = (n * 50) + 80;

    HWND hwnd = CreateWindow("AjedrezPunteros", "Ajedrez", WS_OVERLAPPEDWINDOW,
                             CW_USEDEFAULT, CW_USEDEFAULT, windowWidth, windowHeight,
                             NULL, NULL, hInstance, NULL);

    ShowWindow(hwnd, SW_SHOW);

    MSG msg = {0};
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    // 5. Limpieza de memoria (Muy importante al usar new)
    delete[] tableroDatos;
    delete[] movimientosValidos;
    delete[] movFila;
    delete[] movCol;

    return 0;
}