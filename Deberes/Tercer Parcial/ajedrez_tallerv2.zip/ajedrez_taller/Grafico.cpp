#include <windows.h>
#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

void DibujarCaballoPixelado(HDC hdc, int startX, int startY, int tamanoCelda) {
    int caballo[8][8] = {
        {0, 0, 1, 1, 0, 0, 0, 0},
        {0, 1, 1, 1, 1, 0, 0, 0},
        {0, 0, 1, 1, 1, 1, 0, 0},
        {0, 0, 0, 1, 1, 0, 0, 0},
        {0, 0, 0, 1, 1, 0, 0, 0},
        {0, 0, 1, 1, 1, 1, 0, 0},
        {0, 1, 1, 1, 1, 1, 1, 0},
        {1, 1, 1, 1, 1, 1, 1, 1}
    };
    
    int tamanoPixel = tamanoCelda / 8; 
    HBRUSH brochaCaballo = CreateSolidBrush(RGB(200, 50, 50)); 
    
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
            if (caballo[i][j] == 1) {
                RECT p;
                p.left = startX + (j * tamanoPixel);
                p.top = startY + (i * tamanoPixel);
                p.right = p.left + tamanoPixel;
                p.bottom = p.top + tamanoPixel;
                FillRect(hdc, &p, brochaCaballo);
            }
        }
    }
    DeleteObject(brochaCaballo);
}

int main() {
    ifstream archivo("tablero.txt");
    if (!archivo.is_open()) {
        cout << "Error: No se encontro 'tablero.txt'." << endl;
        system("pause");
        return 1;
    }

    vector<int> datos;
    int valor;
    while (archivo >> valor) {
        datos.push_back(valor);
    }
    archivo.close();

    int n = 0;
    while (n * n < datos.size()) n++;

    int cabFila, cabCol;
    cout << "--- SIMULADOR DEL CABALLO ---" << endl;
    cout << "Tablero de " << n << "x" << n << " detectado." << endl;
    cout << "Ingrese la Fila del caballo (0 a " << n - 1 << "): ";
    cin >> cabFila;
    cout << "Ingrese la Columna del caballo (0 a " << n - 1 << "): ";
    cin >> cabCol;

    if (cabFila < 0 || cabFila >= n || cabCol < 0 || cabCol >= n) {
        cout << "Posicion invalida." << endl;
        system("pause");
        return 1;
    }

    int movFila[] = {-2, -2, -1, -1, 1, 1, 2, 2};
    int movCol[]  = {-1,  1, -2,  2, -2, 2, -1, 1};
    vector<vector<bool>> movimientosValidos(n, vector<bool>(n, false));

    for (int k = 0; k < 8; k++) {
        int nuevaFila = cabFila + movFila[k];
        int nuevaCol = cabCol + movCol[k];
        if (nuevaFila >= 0 && nuevaFila < n && nuevaCol >= 0 && nuevaCol < n) {
            movimientosValidos[nuevaFila][nuevaCol] = true;
        }
    }

    // LIMPIAR LA CONSOLA PARA DIBUJAR SIN ESTORBOS
    system("cls");
    cout << "Cierra esta ventana para terminar el programa." << endl;

    HWND console = GetConsoleWindow(); 
    HDC hdc = GetDC(console);          

    int tamanoCelda = 50; 
    int offsetX = 20;     
    int offsetY = 40; // Subimos el dibujo para que se vea mejor   

    HBRUSH brochaBlanca = CreateSolidBrush(RGB(240, 240, 240));
    HBRUSH brochaNegra = CreateSolidBrush(RGB(100, 100, 100));
    HBRUSH brochaVerde = CreateSolidBrush(RGB(50, 200, 50)); 

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            int index = i * n + j;

            RECT rect;
            rect.left = offsetX + (j * tamanoCelda);
            rect.top = offsetY + (i * tamanoCelda);
            rect.right = rect.left + tamanoCelda;
            rect.bottom = rect.top + tamanoCelda;

            if (movimientosValidos[i][j]) {
                FillRect(hdc, &rect, brochaVerde); 
            } else if (datos[index] == 0) {
                FillRect(hdc, &rect, brochaBlanca);
            } else {
                FillRect(hdc, &rect, brochaNegra);
            }
            
            if (i == cabFila && j == cabCol) {
                if (datos[index] == 0) FillRect(hdc, &rect, brochaBlanca);
                else FillRect(hdc, &rect, brochaNegra);
                
                DibujarCaballoPixelado(hdc, rect.left, rect.top, tamanoCelda);
            }
        }
    }

    DeleteObject(brochaBlanca);
    DeleteObject(brochaNegra);
    DeleteObject(brochaVerde);
    ReleaseDC(console, hdc);

    // Evitar que el programa se cierre al instante
    cin.ignore();
    cin.get();
    return 0;
}