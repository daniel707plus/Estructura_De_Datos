#ifndef RBTREE_H
#define RBTREE_H

// Renombramos para evitar el choque con Raylib
enum NodeColor { RED_NODE, BLACK_NODE };

class RBNode {
public:
    int data;
    NodeColor color; // Usamos el nuevo nombre
    RBNode *left;
    RBNode *right;
    RBNode *parent;

    RBNode(int val);
    void draw(int x, int y, int offsetX); 
};

class RBTree {
private:
    RBNode *root;
    void leftRotate(RBNode *x);
    void rightRotate(RBNode *x);
    void fixInsert(RBNode *k);

public:
    RBTree();
    void insert(int val);
    void draw(int startX, int startY);
};

#endif