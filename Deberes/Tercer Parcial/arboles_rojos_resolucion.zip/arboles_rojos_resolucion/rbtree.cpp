#include "rbtree.h"
#include "raylib.h"
#include <string>

// --- Implementación de RBNode ---
RBNode::RBNode(int val) {
    data = val;
    color = RED_NODE; // Todo nodo nuevo entra siendo rojo
    left = nullptr;
    right = nullptr;
    parent = nullptr;
}

void RBNode::draw(int x, int y, int offsetX) {
    if (left != nullptr) {
        int childX = x - offsetX;
        int childY = y + 80;
        DrawLine(x, y, childX, childY, DARKGRAY);
        left->draw(childX, childY, offsetX / 2);
    }
    
    if (right != nullptr) {
        int childX = x + offsetX;
        int childY = y + 80;
        DrawLine(x, y, childX, childY, DARKGRAY);
        right->draw(childX, childY, offsetX / 2);
    }

    // Aquí sí usamos el struct Color de Raylib
    Color circleColor = (color == RED_NODE) ? MAROON : BLACK;
    DrawCircle(x, y, 20, circleColor);
    DrawCircleLines(x, y, 20, RAYWHITE); 

    std::string text = std::to_string(data);
    int textWidth = MeasureText(text.c_str(), 16);
    DrawText(text.c_str(), x - (textWidth / 2), y - 8, 16, RAYWHITE);
}

// --- Implementación de RBTree ---
RBTree::RBTree() {
    root = nullptr;
}

void RBTree::leftRotate(RBNode *x) {
    RBNode *y = x->right;
    x->right = y->left;
    if (y->left != nullptr) y->left->parent = x;
    y->parent = x->parent;
    if (x->parent == nullptr) root = y;
    else if (x == x->parent->left) x->parent->left = y;
    else x->parent->right = y;
    y->left = x;
    x->parent = y;
}

void RBTree::rightRotate(RBNode *x) {
    RBNode *y = x->left;
    x->left = y->right;
    if (y->right != nullptr) y->right->parent = x;
    y->parent = x->parent;
    if (x->parent == nullptr) root = y;
    else if (x == x->parent->right) x->parent->right = y;
    else x->parent->left = y;
    y->right = x;
    x->parent = y;
}

void RBTree::fixInsert(RBNode *k) {
    RBNode *u; 
    while (k->parent != nullptr && k->parent->color == RED_NODE) {
        if (k->parent == k->parent->parent->right) {
            u = k->parent->parent->left;
            if (u != nullptr && u->color == RED_NODE) {
                u->color = BLACK_NODE;
                k->parent->color = BLACK_NODE;
                k->parent->parent->color = RED_NODE;
                k = k->parent->parent;
            } else {
                if (k == k->parent->left) {
                    k = k->parent;
                    rightRotate(k);
                }
                k->parent->color = BLACK_NODE;
                k->parent->parent->color = RED_NODE;
                leftRotate(k->parent->parent);
            }
        } else {
            u = k->parent->parent->right;
            if (u != nullptr && u->color == RED_NODE) {
                u->color = BLACK_NODE;
                k->parent->color = BLACK_NODE;
                k->parent->parent->color = RED_NODE;
                k = k->parent->parent;
            } else {
                if (k == k->parent->right) {
                    k = k->parent;
                    leftRotate(k);
                }
                k->parent->color = BLACK_NODE;
                k->parent->parent->color = RED_NODE;
                rightRotate(k->parent->parent);
            }
        }
        if (k == root) break;
    }
    root->color = BLACK_NODE; // La raíz siempre debe ser negra
}

void RBTree::insert(int val) {
    RBNode *node = new RBNode(val);
    RBNode *y = nullptr;
    RBNode *x = root;

    while (x != nullptr) {
        y = x;
        if (node->data < x->data) x = x->left;
        else x = x->right;
    }

    node->parent = y;
    if (y == nullptr) root = node;
    else if (node->data < y->data) y->left = node;
    else y->right = node;

    if (node->parent == nullptr) {
        node->color = BLACK_NODE;
        return;
    }
    
    if (node->parent->parent == nullptr) return;

    fixInsert(node);
}

void RBTree::draw(int startX, int startY) {
    if (root != nullptr) {
        root->draw(startX, startY, startX / 2);
    }
}