#include "raylib.h"
#include "rbtree.h" 

//g++ main.cpp rbtree.cpp -o arbol_rojo.exe -L. -lraylib -lopengl32 -lgdi32 -lwinmm
//.\arbol_rojo.exe

int main() {
    InitWindow(100, 100, "Inicializando..."); 
    int screenWidth = GetMonitorWidth(0);   
    int screenHeight = GetMonitorHeight(0);
    CloseWindow(); 

    int windowWidth = screenWidth - 100;
    int windowHeight = screenHeight - 150;
    InitWindow(windowWidth, windowHeight, "Arbol Rojinegro con Raylib");
    SetTargetFPS(60);

    RBTree tree; 
    
    // Inserciones una por una para evitar el uso de corchetes "[]" en arreglos
    tree.insert(10);
    tree.insert(20);
    tree.insert(30);  // Aquí el árbol rotará y la raíz pasará a ser 20
    tree.insert(15);
    tree.insert(25);
    tree.insert(5);
    tree.insert(1);
    tree.insert(2);   // Rotaciones múltiples en acción

    int startX = windowWidth / 2;
    int startY = 80;

    while (!WindowShouldClose()) {
        BeginDrawing();
        ClearBackground(LIGHTGRAY); 

        DrawText("ARBOL ROJo (Autobalanceado)", 20, 20, 20, DARKGRAY);
        
        // Dibujar el árbol
        tree.draw(startX, startY);

        EndDrawing();
    }

    CloseWindow();
    return 0;
}